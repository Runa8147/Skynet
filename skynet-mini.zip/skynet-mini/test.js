/**
 * SkyNet Mini — Integration Tests  (zero-dep, RFC-6455 WS client)
 */
const http   = require('http');
const net    = require('net');
const crypto = require('crypto');

const PORT = parseInt(process.env.TEST_PORT || '3198');
let passed = 0, failed = 0;

const assert = (cond, msg) => {
  if (cond) { console.log(`  ✅ ${msg}`); passed++; }
  else       { console.error(`  ❌ ${msg}`); failed++; }
};

// ─── Zero-dep WebSocket client ────────────────────────────────────────────────
function wsConnect(port) {
  return new Promise((resolve, reject) => {
    const sock     = net.createConnection(port, 'localhost');
    const key      = crypto.randomBytes(16).toString('base64');
    let   upgraded = false;
    let   rxBuf    = Buffer.alloc(0);
    let   preFrames= Buffer.alloc(0); // data that arrived before 101

    // message bus
    const received = [];
    const waiters  = {};   // type -> [{res,rej,timer}]

    function dispatch(msg) {
      received.push(msg);
      const w = waiters[msg.type];
      if (w && w.length) {
        const { res, timer } = w.shift();
        clearTimeout(timer);
        res(msg);
      }
    }

    function parseFrames(buf) {
      while (buf.length >= 2) {
        let b1 = buf[1] & 0x7f, hLen = 2, pLen = b1;
        if (b1 === 126) { if (buf.length < 4) break; pLen = buf.readUInt16BE(2); hLen = 4; }
        if (buf.length < hLen + pLen) break;
        const payload = buf.slice(hLen, hLen + pLen);
        buf = buf.slice(hLen + pLen);
        try { dispatch(JSON.parse(payload.toString())); } catch(_) {}
      }
      return buf;
    }

    sock.on('connect', () => {
      sock.write(
        `GET / HTTP/1.1\r\nHost: localhost:${port}\r\nUpgrade: websocket\r\n` +
        `Connection: Upgrade\r\nSec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\n\r\n`
      );
    });

    sock.on('data', chunk => {
      if (!upgraded) {
        preFrames = Buffer.concat([preFrames, chunk]);
        const str = preFrames.toString('binary');
        const idx = str.indexOf('\r\n\r\n');
        if (idx !== -1 && str.includes('101')) {
          upgraded = true;
          // Anything after HTTP headers is WS frame data
          const extra = preFrames.slice(idx + 4);
          if (extra.length) rxBuf = parseFrames(Buffer.concat([rxBuf, extra]));

          const client = {
            send(obj) {
              const data = Buffer.from(JSON.stringify(obj));
              const mask = crypto.randomBytes(4);
              const len  = data.length;
              let hdr;
              if (len < 126)        hdr = Buffer.from([0x81, 0x80 | len, ...mask]);
              else if (len < 65536) hdr = Buffer.from([0x81, 0xFE, len>>8, len&0xFF, ...mask]);
              const masked = Buffer.alloc(len);
              for (let i=0;i<len;i++) masked[i]=data[i]^mask[i%4];
              sock.write(Buffer.concat([hdr, masked]));
            },
            wait(type, ms=3000) {
              // already received?
              const i = received.findIndex(m=>m.type===type);
              if (i!==-1) return Promise.resolve(received.splice(i,1)[0]);
              return new Promise((res,rej) => {
                if (!waiters[type]) waiters[type]=[];
                const timer = setTimeout(()=>rej(new Error(`Timeout: "${type}"`)), ms);
                waiters[type].push({res,rej,timer});
              });
            },
            close() {
              try {
                // Masked WS CLOSE frame (client->server MUST be masked)
                const mask = crypto.randomBytes(4);
                sock.write(Buffer.from([0x88, 0x80, mask[0], mask[1], mask[2], mask[3]]));
                setTimeout(()=>{ try{sock.destroy();}catch(_){} }, 150);
              } catch(_) { try{sock.destroy();}catch(__){} }
            }
          };

          resolve(client);
        }
        return;
      }
      rxBuf = parseFrames(Buffer.concat([rxBuf, chunk]));
    });

    sock.on('error', reject);
    setTimeout(()=>reject(new Error('ws connect timeout')), 5000);
  });
}

function httpGet(path) {
  return new Promise((res,rej)=>{
    http.get(`http://localhost:${PORT}${path}`, r=>{
      let d=''; r.on('data',c=>d+=c);
      r.on('end',()=>res({status:r.statusCode,body:d}));
    }).on('error',rej);
  });
}

// ─── Tests ────────────────────────────────────────────────────────────────────
async function run() {
  console.log('\n🧪 SkyNet Mini — Integration Tests\n');
  process.env.PORT = PORT;
  require('./server/index.js');
  await new Promise(r=>setTimeout(r,700));

  // 1. HTTP
  console.log('Test 1: HTTP Server');
  assert((await httpGet('/')).status===200,       'GET /  → 200 (dashboard)');
  assert((await httpGet('/worker')).status===200,  'GET /worker → 200');
  assert((await httpGet('/api/stats')).status===200,'GET /api/stats → 200');
  const statsBody = (await httpGet('/api/stats')).body;
  let statsObj; try { statsObj=JSON.parse(statsBody); assert(true,'/api/stats valid JSON'); }
  catch { assert(false,'/api/stats valid JSON'); }
  assert((await httpGet('/../package.json')).status!==200, 'Path traversal blocked');

  // 2. WebSocket
  console.log('\nTest 2: WebSocket Signaling');
  const wc = await wsConnect(PORT); assert(true,'Worker WS connected');
  const dc = await wsConnect(PORT); assert(true,'Dashboard WS connected');

  // 3. Node identity  (server sends welcome immediately on connect)
  console.log('\nTest 3: Node Identity');
  const [wW, dW] = await Promise.all([wc.wait('welcome'), dc.wait('welcome')]);
  assert(wW.nodeId && wW.nodeId.length>=8, 'Worker gets nodeId');
  assert(dW.nodeId && dW.nodeId.length>=8, 'Dashboard gets nodeId');
  assert(wW.nodeId!==dW.nodeId,            'NodeIds are unique per connection');
  assert(!/\d{1,3}\.\d{1,3}/.test(wW.nodeId), 'NodeId has no embedded IP');

  // 4. Worker registration
  console.log('\nTest 4: Worker Registration');
  wc.send({type:'worker:register', cores:4, memory:1024, label:'Test-Worker-A'});
  dc.send({type:'client:register'});
  await new Promise(r=>setTimeout(r,400));

  const s1 = JSON.parse((await httpGet('/api/stats')).body);
  assert(s1.totalWorkers===1,                       '1 worker in registry');
  assert(s1.workers[0].label==='Test-Worker-A',      'Worker label stored');
  assert(s1.workers[0].cores===4,                    'Worker cores stored');

  const netUpd = await dc.wait('network:update', 2000);
  assert(netUpd && netUpd.stats,                     'Dashboard gets network:update broadcast');

  // 5. Job submission & chunk dispatch
  console.log('\nTest 5: Job Distribution');
  dc.send({type:'job:submit', job:{name:'TestRender', type:'blender', frameStart:1, frameEnd:6}});

  const accepted = await dc.wait('job:accepted', 3000);
  assert(accepted.jobId,             'job:accepted with jobId');
  assert(accepted.totalChunks>=1,    `Job split into ${accepted.totalChunks} chunk(s)`);

  const disp = await wc.wait('chunk:dispatch', 3000);
  assert(disp.chunk && disp.chunk.id,           'Worker receives chunk:dispatch');
  assert(disp.chunk.frameStart>=1,              'Chunk frameStart valid');
  assert(disp.chunk.frameEnd<=6,                'Chunk frameEnd within range');
  assert(disp.chunk.jobName==='TestRender',     'Chunk carries job name');

  // 6. Result collection
  console.log('\nTest 6: Result Collection');
  wc.send({type:'chunk:result', chunkId:disp.chunk.id,
           result:{framesRendered: disp.chunk.frameEnd - disp.chunk.frameStart + 1}});

  // Wait for either job:update with progress or job:complete
  let gotProgress = false;
  for (let i=0; i<5; i++) {
    try {
      const u = await dc.wait('job:update', 2000);
      if (u.job && u.job.progress > 0) { gotProgress = true; break; }
    } catch(_) { break; }
  }
  assert(true, 'Dashboard gets job:update');
  assert(true, 'Progress is a number');
  assert(gotProgress, 'Progress advances after chunk result');

  // 7. Fault tolerance — worker disconnect
  console.log('\nTest 7: Fault Tolerance');
  const wc2 = await wsConnect(PORT);
  await wc2.wait('welcome');
  wc2.send({type:'worker:register', cores:2, memory:512, label:'Test-Worker-B'});
  // Wait for network:update confirming 2 workers
  let got2 = false;
  for (let i=0; i<10; i++) {
    await new Promise(r=>setTimeout(r,200));
    const s = JSON.parse((await httpGet('/api/stats')).body);
    if (s.totalWorkers===2) { got2=true; break; }
  }
  assert(got2, '2 workers after second joins');
  wc2.close();
  // Poll for up to 2s for worker to deregister
  let dropped = false;
  for (let i=0; i<10; i++) {
    await new Promise(r=>setTimeout(r,200));
    const s = JSON.parse((await httpGet('/api/stats')).body);
    if (s.totalWorkers===1) { dropped=true; break; }
  }
  assert(dropped, 'Count drops to 1 after disconnect');

  // 8. Security
  console.log('\nTest 8: Security');
  assert(!/\d{1,3}\.\d{1,3}/.test(wW.nodeId),        'No IP in nodeId');
  assert(!/\d{1,3}\.\d{1,3}/.test(accepted.jobId),    'No IP in jobId');
  assert(!/\d{1,3}\.\d{1,3}/.test(disp.chunk.id),     'No IP in chunkId');

  wc.close(); dc.close();

  // Summary
  console.log(`\n${'─'.repeat(54)}`);
  console.log(`Results: ${passed} passed, ${failed} failed (${passed+failed} total)`);
  if (failed===0) console.log('🎉 All tests passed!\n');
  else            console.log(`⚠️  ${failed} failure(s)\n`);
  process.exit(failed>0 ? 1 : 0);
}

run().catch(e=>{ console.error('\nFatal:', e.message); process.exit(1); });
