#!/usr/bin/env bash
# SkyNet Mini — Start Script
# Works on macOS, Linux, WSL. Zero dependencies needed.

set -e

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RESET='\033[0m'

echo ""
echo -e "${CYAN}  ╔══════════════════════════════════════════════╗${RESET}"
echo -e "${CYAN}  ║       SkyNet Mini — Distributed Compute      ║${RESET}"
echo -e "${CYAN}  ╚══════════════════════════════════════════════╝${RESET}"
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
  echo -e "${YELLOW}  ⚠  Node.js not found.${RESET}"
  echo "     Install from https://nodejs.org (v14+ required)"
  exit 1
fi

NODE_VER=$(node -e "process.stdout.write(process.version)")
echo -e "  ${GREEN}✓${RESET} Node.js ${NODE_VER} found"
echo -e "  ${GREEN}✓${RESET} Zero external dependencies — starting immediately"
echo ""

PORT=${PORT:-3000}

echo -e "  ${CYAN}Dashboard →${RESET} http://localhost:${PORT}"
echo -e "  ${CYAN}Worker    →${RESET} http://localhost:${PORT}/worker"
echo ""
echo -e "  Open the ${YELLOW}Dashboard${RESET} to submit render jobs."
echo -e "  Open ${YELLOW}/worker${RESET} in other browser tabs or devices to contribute compute."
echo ""
echo -e "  ${CYAN}Press Ctrl+C to stop${RESET}"
echo ""

PORT=$PORT node "$(dirname "$0")/server/index.js"
