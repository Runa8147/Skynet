@echo off
:: SkyNet Mini — Windows Start Script
:: Zero dependencies. Just run this file.

echo.
echo   +----------------------------------------------+
echo   ^|       SkyNet Mini - Distributed Compute      ^|
echo   +----------------------------------------------+
echo.

:: Check Node.js
where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
  echo   ERROR: Node.js not found.
  echo   Install from https://nodejs.org ^(v14+ required^)
  pause
  exit /b 1
)

for /f "tokens=*" %%i in ('node -e "process.stdout.write(process.version)"') do set NODE_VER=%%i
echo   [OK] Node.js %NODE_VER% found
echo   [OK] Zero external dependencies
echo.

if not defined PORT set PORT=3000

echo   Dashboard  -^>  http://localhost:%PORT%
echo   Worker     -^>  http://localhost:%PORT%/worker
echo.
echo   Open Dashboard to submit jobs.
echo   Open /worker in other tabs/devices to share compute.
echo.
echo   Press Ctrl+C to stop.
echo.

node "%~dp0server\index.js"
pause
