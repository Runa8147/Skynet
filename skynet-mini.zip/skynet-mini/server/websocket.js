/**
 * SkyNet Mini - Zero-dependency WebSocket Server (RFC 6455)
 * Pure Node.js implementation, no external packages needed
 */

const crypto = require('crypto');
const { EventEmitter } = require('events');

const WS_MAGIC = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

// Opcodes
const OP = { CONT: 0, TEXT: 1, BIN: 2, CLOSE: 8, PING: 9, PONG: 10 };

function generateAccept(key) {
  return crypto.createHash('sha1').update(key + WS_MAGIC).digest('base64');
}

function encodeFrame(data, opcode = OP.TEXT) {
  const payload = Buffer.isBuffer(data) ? data : Buffer.from(data, 'utf8');
  const len = payload.length;
  let header;

  if (len < 126) {
    header = Buffer.alloc(2);
    header[0] = 0x80 | opcode;
    header[1] = len;
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }

  return Buffer.concat([header, payload]);
}

function decodeFrames(buf) {
  const frames = [];
  let offset = 0;

  while (offset < buf.length) {
    if (offset + 2 > buf.length) break;

    const b0 = buf[offset];
    const b1 = buf[offset + 1];
    const fin = !!(b0 & 0x80);
    const opcode = b0 & 0x0f;
    const masked = !!(b1 & 0x80);
    let payloadLen = b1 & 0x7f;
    let headerLen = 2;

    if (payloadLen === 126) {
      if (offset + 4 > buf.length) break;
      payloadLen = buf.readUInt16BE(offset + 2);
      headerLen = 4;
    } else if (payloadLen === 127) {
      if (offset + 10 > buf.length) break;
      payloadLen = Number(buf.readBigUInt64BE(offset + 2));
      headerLen = 10;
    }

    if (masked) headerLen += 4;
    if (offset + headerLen + payloadLen > buf.length) break;

    let payload = buf.slice(offset + headerLen, offset + headerLen + payloadLen);

    if (masked) {
      const mask = buf.slice(offset + headerLen - 4, offset + headerLen);
      const unmasked = Buffer.alloc(payloadLen);
      for (let i = 0; i < payloadLen; i++) {
        unmasked[i] = payload[i] ^ mask[i % 4];
      }
      payload = unmasked;
    }

    frames.push({ fin, opcode, payload });
    offset += headerLen + payloadLen;
  }

  return frames;
}

class WSClient extends EventEmitter {
  constructor(socket, id) {
    super();
    this.socket = socket;
    this.id = id;
    this.alive = true;
    this._fragBuf = null;
    this._fragOp = null;
    this._buf = Buffer.alloc(0);

    socket.on('data', (chunk) => this._onData(chunk));
    socket.on('close', () => { this.alive = false; this.emit('close'); });
    socket.on('error', (e) => { this.alive = false; this.emit('error', e); });
  }

  _onData(chunk) {
    this._buf = Buffer.concat([this._buf, chunk]);
    const frames = decodeFrames(this._buf);

    // Recalculate consumed bytes
    let consumed = 0;
    for (const frame of frames) {
      const b1 = this._buf[consumed + 1] & 0x7f;
      let hLen = 2;
      if (b1 === 126) hLen = 4;
      else if (b1 === 127) hLen = 10;
      if (this._buf[consumed + 1] & 0x80) hLen += 4;
      let pLen = frame.payload.length;
      consumed += hLen + pLen;

      if (frame.opcode === OP.CLOSE) {
        this.close();
        return;
      }
      if (frame.opcode === OP.PING) {
        this.socket.write(encodeFrame(frame.payload, OP.PONG));
        continue;
      }
      if (frame.opcode === OP.CONT) {
        if (this._fragBuf) this._fragBuf = Buffer.concat([this._fragBuf, frame.payload]);
        if (frame.fin && this._fragBuf) {
          this.emit('message', this._fragBuf.toString('utf8'));
          this._fragBuf = null; this._fragOp = null;
        }
      } else if (!frame.fin) {
        this._fragBuf = frame.payload;
        this._fragOp = frame.opcode;
      } else {
        this.emit('message', frame.payload.toString('utf8'));
      }
    }
    this._buf = this._buf.slice(consumed);
  }

  send(data) {
    if (!this.alive) return;
    try {
      const str = typeof data === 'string' ? data : JSON.stringify(data);
      this.socket.write(encodeFrame(str, OP.TEXT));
    } catch (e) { /* socket closed */ }
  }

  close() {
    this.alive = false;
    try { this.socket.write(encodeFrame(Buffer.alloc(0), OP.CLOSE)); } catch (_) {}
    try { this.socket.destroy(); } catch (_) {}
    this.emit('close');
  }
}

class WSServer extends EventEmitter {
  constructor(httpServer) {
    super();
    httpServer.on('upgrade', (req, socket, head) => {
      const key = req.headers['sec-websocket-key'];
      if (!key) { socket.destroy(); return; }

      const accept = generateAccept(key);
      socket.write(
        'HTTP/1.1 101 Switching Protocols\r\n' +
        'Upgrade: websocket\r\n' +
        'Connection: Upgrade\r\n' +
        `Sec-WebSocket-Accept: ${accept}\r\n\r\n`
      );

      const id = crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex');
      const client = new WSClient(socket, id);
      this.emit('connection', client, req);
    });
  }
}

module.exports = { WSServer, WSClient };
