/**
 * SkyNet Mini - Main Server
 * Zero external dependencies. Pure Node.js.
 * 
 * Architecture:
 *  - HTTP server serves static files
 *  - WebSocket signaling for WebRTC peer discovery
 *  - Job queue management
 *  - Worker registry
 *  - No IPs exposed to clients
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WSServer } = require('./websocket');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

// ─── State ────────────────────────────────────────────────────────────────────
const workers = new Map();      // workerId -> { ws, info, busy, peerId }
const clients = new Map();      // clientId -> { ws, jobs }
const jobs = new Map();         // jobId -> job object
const pendingChunks = new Map(); // chunkId -> chunk object
const rtcPeers = new Map();     // peerId -> ws (for WebRTC signaling)

// ─── MIME Types ───────────────────────────────────────────────────────────────
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.wasm': 'application/wasm',
};

// ─── HTTP Server ──────────────────────────────────────────────────────────────
const httpServer = http.createServer((req, res) => {
  let urlPath = req.url.split('?')[0];
  if (urlPath === '/') urlPath = '/client/index.html';
  if (urlPath === '/worker') urlPath = '/worker/index.html';

  // API endpoints
  if (urlPath === '/api/stats') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify(getStats()));
    return;
  }

  const filePath = path.join(PUBLIC_DIR, urlPath);

  // Security: prevent directory traversal
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403); res.end('Forbidden'); return;
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') { res.writeHead(404); res.end('Not found'); }
      else { res.writeHead(500); res.end('Server error'); }
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
});

// ─── WebSocket Signaling ──────────────────────────────────────────────────────
const wss = new WSServer(httpServer);

wss.on('connection', (ws, req) => {
  ws.nodeId = genId();
  rtcPeers.set(ws.nodeId, ws);

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    handleMessage(ws, msg);
  });

  ws.on('close', () => {
    rtcPeers.delete(ws.nodeId);
    handleDisconnect(ws);
  });

  ws.send({ type: 'welcome', nodeId: ws.nodeId });
});

// ─── Message Router ───────────────────────────────────────────────────────────
function handleMessage(ws, msg) {
  switch (msg.type) {

    // Worker registration
    case 'worker:register':
      ws.role = 'worker';
      ws.workerId = ws.nodeId;
      workers.set(ws.workerId, {
        ws, busy: false,
        cores: msg.cores || 1,
        memory: msg.memory || 512,
        label: msg.label || 'Anonymous Node',
        joinedAt: Date.now(),
        tasksCompleted: 0,
        peerId: ws.nodeId
      });
      broadcast({ type: 'network:update', stats: getStats() });
      console.log(`[+] Worker joined: ${ws.workerId} (${msg.cores} cores)`);
      break;

    // Client registration
    case 'client:register':
      ws.role = 'client';
      ws.clientId = ws.nodeId;
      clients.set(ws.clientId, { ws, jobs: [] });
      ws.send({ type: 'network:update', stats: getStats() });
      break;

    // Job submission
    case 'job:submit':
      handleJobSubmit(ws, msg);
      break;

    // Chunk result from worker
    case 'chunk:result':
      handleChunkResult(ws, msg);
      break;

    // WebRTC signaling passthrough (SDP offer/answer, ICE candidates)
    case 'rtc:offer':
    case 'rtc:answer':
    case 'rtc:ice':
      relayRTC(ws, msg);
      break;

    // Worker heartbeat
    case 'worker:heartbeat':
      if (workers.has(ws.workerId)) {
        workers.get(ws.workerId).lastSeen = Date.now();
      }
      break;

    case 'chunk:ack':
      // Worker acknowledged chunk receipt
      break;
  }
}

// ─── Job Handling ─────────────────────────────────────────────────────────────
function handleJobSubmit(ws, msg) {
  const jobId = genId();
  const chunks = splitJob(msg.job, jobId);

  const job = {
    id: jobId,
    clientId: ws.clientId || ws.nodeId,
    name: msg.job.name || 'Unnamed Job',
    type: msg.job.type || 'render',
    totalChunks: chunks.length,
    completedChunks: 0,
    results: [],
    status: 'queued',
    createdAt: Date.now(),
    startedAt: null,
    completedAt: null,
    chunks: chunks.map(c => c.id),
  };

  jobs.set(jobId, job);
  chunks.forEach(c => pendingChunks.set(c.id, c));

  ws.send({ type: 'job:accepted', jobId, totalChunks: chunks.length });
  console.log(`[Job] ${job.name} (${chunks.length} chunks)`);

  dispatchChunks();
  broadcastJobUpdate(jobId);
}

function splitJob(jobDef, jobId) {
  const frameStart = jobDef.frameStart || 1;
  const frameEnd = jobDef.frameEnd || 10;
  const totalFrames = frameEnd - frameStart + 1;
  const chunkSize = Math.max(1, Math.ceil(totalFrames / Math.max(1, workers.size || 1)));
  const chunks = [];

  for (let f = frameStart; f <= frameEnd; f += chunkSize) {
    const end = Math.min(f + chunkSize - 1, frameEnd);
    chunks.push({
      id: genId(),
      jobId,
      frameStart: f,
      frameEnd: end,
      status: 'pending',
      workerId: null,
      result: null,
      dispatchedAt: null,
      retries: 0,
    });
  }
  return chunks;
}

function dispatchChunks() {
  for (const [chunkId, chunk] of pendingChunks) {
    if (chunk.status !== 'pending') continue;

    const worker = getIdleWorker();
    if (!worker) break;

    chunk.status = 'dispatched';
    chunk.workerId = worker.ws.workerId || worker.ws.nodeId;
    chunk.dispatchedAt = Date.now();
    worker.busy = true;

    const job = jobs.get(chunk.jobId);
    if (job && job.status === 'queued') {
      job.status = 'running';
      job.startedAt = Date.now();
    }

    worker.ws.send({
      type: 'chunk:dispatch',
      chunk: {
        id: chunk.id,
        jobId: chunk.jobId,
        jobName: job ? job.name : 'Job',
        jobType: job ? job.type : 'render',
        frameStart: chunk.frameStart,
        frameEnd: chunk.frameEnd,
      }
    });

    console.log(`[Dispatch] Chunk ${chunk.frameStart}-${chunk.frameEnd} -> worker ${chunk.workerId}`);
    broadcastJobUpdate(chunk.jobId);
  }
}

function handleChunkResult(ws, msg) {
  const chunk = pendingChunks.get(msg.chunkId);
  if (!chunk) return;

  chunk.status = 'done';
  chunk.result = msg.result;
  pendingChunks.delete(msg.chunkId);

  const worker = workers.get(ws.workerId || ws.nodeId);
  if (worker) { worker.busy = false; worker.tasksCompleted++; }

  const job = jobs.get(chunk.jobId);
  if (!job) return;

  job.completedChunks++;
  job.results.push({ frames: `${chunk.frameStart}-${chunk.frameEnd}`, data: msg.result });

  if (job.completedChunks >= job.totalChunks) {
    job.status = 'done';
    job.completedAt = Date.now();
    console.log(`[Done] Job ${job.name} completed`);

    // Notify originating client
    const clientEntry = clients.get(job.clientId);
    if (clientEntry) {
      clientEntry.ws.send({
        type: 'job:complete',
        jobId: job.id,
        name: job.name,
        results: job.results,
        duration: job.completedAt - job.startedAt,
      });
    }
  }

  broadcastJobUpdate(job.id);
  broadcast({ type: 'network:update', stats: getStats() });
  dispatchChunks(); // try dispatching more
}

// ─── WebRTC Relay ─────────────────────────────────────────────────────────────
function relayRTC(senderWs, msg) {
  const target = rtcPeers.get(msg.to);
  if (target && target.alive !== false) {
    target.send({ ...msg, from: senderWs.nodeId });
  }
}

// ─── Disconnect Handling ──────────────────────────────────────────────────────
function handleDisconnect(ws) {
  if (ws.role === 'worker') {
    const workerId = ws.workerId || ws.nodeId;
    workers.delete(workerId);
    console.log(`[-] Worker left: ${workerId}`);

    // Re-queue any chunks this worker had
    for (const [cid, chunk] of pendingChunks) {
      if (chunk.workerId === workerId && chunk.status === 'dispatched') {
        chunk.status = 'pending';
        chunk.workerId = null;
        chunk.retries++;
      }
    }
    dispatchChunks();
    broadcast({ type: 'network:update', stats: getStats() });
  } else if (ws.role === 'client') {
    clients.delete(ws.clientId || ws.nodeId);
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function getIdleWorker() {
  for (const [, w] of workers) {
    if (!w.busy) return w;
  }
  return null;
}

function genId() {
  return crypto.randomBytes(8).toString('hex');
}

function getStats() {
  const jobList = [...jobs.values()].map(j => ({
    id: j.id, name: j.name, type: j.type, status: j.status,
    progress: j.totalChunks > 0 ? Math.round((j.completedChunks / j.totalChunks) * 100) : 0,
    totalChunks: j.totalChunks, completedChunks: j.completedChunks,
    createdAt: j.createdAt, startedAt: j.startedAt, completedAt: j.completedAt,
  }));

  const workerList = [...workers.values()].map(w => ({
    id: w.ws.workerId || w.ws.nodeId,
    label: w.label, busy: w.busy,
    cores: w.cores, memory: w.memory,
    tasksCompleted: w.tasksCompleted,
    joinedAt: w.joinedAt,
  }));

  return {
    workers: workerList,
    jobs: jobList,
    totalWorkers: workers.size,
    idleWorkers: [...workers.values()].filter(w => !w.busy).length,
    activeJobs: jobList.filter(j => j.status === 'running').length,
    completedJobs: jobList.filter(j => j.status === 'done').length,
    pendingChunks: [...pendingChunks.values()].filter(c => c.status === 'pending').length,
    timestamp: Date.now(),
  };
}

function broadcast(msg) {
  const str = JSON.stringify(msg);
  for (const [, c] of clients) {
    try { c.ws.send(str); } catch (_) {}
  }
  // also send to any connected workers watching
  for (const [, w] of workers) {
    try { w.ws.send(str); } catch (_) {}
  }
}

function broadcastJobUpdate(jobId) {
  const job = jobs.get(jobId);
  if (!job) return;
  broadcast({
    type: 'job:update',
    job: {
      id: job.id, name: job.name, status: job.status,
      progress: job.totalChunks > 0 ? Math.round((job.completedChunks / job.totalChunks) * 100) : 0,
      completedChunks: job.completedChunks, totalChunks: job.totalChunks,
    }
  });
}

// ─── Heartbeat / Stale Worker Cleanup ────────────────────────────────────────
setInterval(() => {
  const now = Date.now();
  for (const [id, w] of workers) {
    if (w.lastSeen && now - w.lastSeen > 30000) {
      console.log(`[Timeout] Worker ${id} timed out`);
      w.ws.close();
      workers.delete(id);
    }
  }
}, 15000);

// ─── Start ────────────────────────────────────────────────────────────────────
httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔══════════════════════════════════════════════════╗
║          SkyNet Mini - Distributed Compute        ║
╠══════════════════════════════════════════════════╣
║  Dashboard  →  http://localhost:${PORT}             ║
║  Worker     →  http://localhost:${PORT}/worker      ║
║  Zero dependencies. Pure Node.js.                ║
╚══════════════════════════════════════════════════╝
`);
});
