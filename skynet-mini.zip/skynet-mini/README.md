# ⚡ SkyNet Mini — Distributed Compute Sharing Tool

A lightweight, **zero-dependency** distributed rendering and compute tool that lets you pool idle browser/computer resources to process heavy tasks like Blender frame rendering, Monte Carlo simulations, and general compute jobs — all from a browser.

---

## ✨ Features

- **Zero external dependencies** — runs with `node server/index.js`, nothing to install
- **No IP exposure** — nodes communicate via anonymous hex IDs, never raw IPs
- **No OS dependency issues** — pure Node.js built-ins only (`http`, `crypto`, `net`, `fs`)
- **WebSocket signaling** — hand-rolled RFC 6455 implementation, no `ws` package needed
- **Auto chunk splitting** — jobs are split across available workers automatically
- **Live dashboard** — real-time job progress, worker status, network stats
- **Worker UI** — beautiful per-node status page with CPU simulation and activity log
- **Fault tolerant** — worker disconnects re-queue their chunks automatically
- **Multi-device** — open `/worker` on phones, laptops, any device on the same network

---

## 🚀 Quick Start

### 1. Start the server

**macOS / Linux / WSL:**
```bash
./start.sh
# or
node server/index.js
```

**Windows:**
```
start.bat
```

**Custom port:**
```bash
PORT=8080 node server/index.js
```

### 2. Open the Dashboard
```
http://localhost:3000
```
Click **CONNECT**, then submit a render job.

### 3. Add worker nodes
Open this URL in other browser tabs, other computers on your network, or your phone:
```
http://localhost:3000/worker
```
Each worker clicks **JOIN NETWORK** and starts accepting render chunks.

---

## 🏗 Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    SkyNet Mini Server                    │
│              (Node.js, zero dependencies)                │
│                                                          │
│  ┌──────────────┐   ┌────────────────────────────────┐  │
│  │  HTTP Server │   │     WebSocket Signaling Bus     │  │
│  │  Static files│   │  RFC 6455 — hand-rolled, no ws  │  │
│  │  /api/stats  │   │  Anonymous hex IDs, no IPs      │  │
│  └──────────────┘   └────────────────────────────────┘  │
│                                                          │
│  ┌──────────────────────────────────────────────────┐   │
│  │              Job Scheduler                        │   │
│  │  • Splits jobs into frame-range chunks            │   │
│  │  • Dispatches to idle workers                     │   │
│  │  • Collects results & reassembles                 │   │
│  │  • Re-queues chunks on worker disconnect          │   │
│  └──────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
         ▲  WebSocket        ▲  WebSocket
         │                   │
┌────────┴──────┐   ┌────────┴──────────────────────────┐
│  Dashboard    │   │  Worker Node (browser page)        │
│  /            │   │  /worker                           │
│               │   │                                    │
│  • Submit job │   │  • Registers cores/memory          │
│  • See workers│   │  • Receives frame chunks           │
│  • Job queue  │   │  • Simulates render (CPU work)     │
│  • Live stats │   │  • Reports results back            │
└───────────────┘   └────────────────────────────────────┘
```

---

## 📁 File Structure

```
skynet-mini/
├── server/
│   ├── index.js          # Main server — HTTP + WebSocket + job scheduler
│   └── websocket.js      # RFC 6455 WebSocket — zero dependencies
├── public/
│   ├── client/
│   │   └── index.html    # Control panel dashboard
│   └── worker/
│       └── index.html    # Worker node browser page
├── test.js               # Integration test suite (29 assertions)
├── start.sh              # Unix/macOS/WSL launcher
├── start.bat             # Windows launcher
└── README.md
```

---

## 🔌 WebSocket Message Protocol

All messages are JSON over WebSocket.

### Client → Server

| Message | Fields | Description |
|---|---|---|
| `client:register` | — | Register as a dashboard client |
| `worker:register` | `cores`, `memory`, `label` | Register as a compute worker |
| `job:submit` | `job` object | Submit a render job |
| `chunk:result` | `chunkId`, `result` | Return completed chunk |
| `worker:heartbeat` | — | Keep-alive ping |
| `rtc:offer/answer/ice` | `to`, payload | WebRTC signaling relay |

### Server → Client

| Message | Fields | Description |
|---|---|---|
| `welcome` | `nodeId` | Assigned anonymous node ID |
| `network:update` | `stats` | Full network state |
| `job:accepted` | `jobId`, `totalChunks` | Job queued confirmation |
| `job:update` | `job` | Progress update |
| `job:complete` | `jobId`, `results`, `duration` | Job finished |
| `chunk:dispatch` | `chunk` | Work assignment to worker |

---

## 🧪 Running Tests

```bash
node test.js
# or on a specific port
TEST_PORT=4000 node test.js
```

Tests cover: HTTP serving, WebSocket handshake, node identity (no IPs), worker registration, job distribution, chunk dispatch, result collection, fault tolerance on disconnect, and security checks.

---

## 🔧 Configuration

| Environment Variable | Default | Description |
|---|---|---|
| `PORT` | `3000` | HTTP + WebSocket port |

---

## 🔒 Security Design

- **No IPs ever sent to clients** — all nodes are identified by random hex IDs (`crypto.randomBytes`)
- **Path traversal blocked** — file serving validates all paths stay within `public/`
- **No authentication by design** — intended for trusted local networks
- **WebRTC relay** — the server relays SDP/ICE without storing or exposing peer addresses

---

## 🗺 Roadmap to SkyNet Major

| Feature | Mini | Major |
|---|---|---|
| Frame chunk distribution | ✅ | ✅ |
| Browser worker nodes | ✅ | ✅ |
| Real Blender integration | Simulated | ✅ via CLI |
| WebRTC P2P data transfer | Signaling only | ✅ Full |
| Genetic Algorithm scheduling | ❌ | ✅ |
| AI-driven task allocation | ❌ | ✅ |
| Multi-job priority queue | ❌ | ✅ |
| Authentication / namespaces | ❌ | ✅ |
| Docker deployment | ❌ | ✅ |

---

## 📄 License

MIT — use freely for academic, personal, and commercial projects.
